﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XmlConvertor
{
    public class Flashcard
    {
        public string L1Topic { get; set; }

        public string L2Topic { get; set; }

        public string L3Topic { get; set; }

        public string Question { get; set; }

        public string Answer { get; set; }

        public string KaplanId { get; set; }

        public string Title { get; set; }
    }
}
